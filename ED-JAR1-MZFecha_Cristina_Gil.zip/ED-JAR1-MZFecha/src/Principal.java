import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {

        MZFecha m1 = new MZFecha(01,02,1998);
        MZFecha m2 = new MZFecha(02,05,2001);

        Scanner sc = new Scanner(System.in);

        System.out.println("Por favor, introduzca el día");
        m1.setDia(sc.nextInt());

        System.out.println("Por favor, introduzca el mes");
        m1.setMes(sc.nextInt());

        System.out.println("Por favor, introduzca el año");
        m1.setAnyo(sc.nextInt());

        System.out.println("Por favor, introduzca el día");
        m2.setDia(sc.nextInt());

        System.out.println("Por favor, introduzca el mes");
        m2.setMes(sc.nextInt());

        System.out.println("Por favor, introduzca el año");
        m2.setAnyo(sc.nextInt());

        m1.diferenciaDias(m2);
        m1.imprime();
        m2.imprime();
    }
}
